// Sign-up page. Opens once when the extension is installed; afterwards it
// doubles as the "what is this / how do I uninstall" page.
// Its wording comes from the Copy tab of the sheet.
const $ = (id) => document.getElementById(id);
const firstName = (name) => String(name || "").trim().split(/\s+/)[0];

(async () => {
  const config = await chrome.runtime.sendMessage({ type: "config", fresh: true });
  if (!config || !config.copy) { $("offline").hidden = false; return; }
  const copy = ProbeForm.copy(config);

  ProbeForm.paint(document, copy);
  $("page").hidden = false;

  function showDone(s) {
    $("signup").hidden = true;
    $("done").hidden = false;
    ProbeForm.fillInto($("done-heading"), copy.done_heading, { name: firstName(s.name) });
    // The app helper's install lines, with this person's code already in them.
    $("mac").textContent = "curl -fsSL " + self.PROBE_SITE + "/install.sh | bash -s -- " + s.code;
    $("windows").textContent = "$env:PAUSE_CODE='" + s.code + "'; irm " + self.PROBE_SITE + "/install.ps1 | iex";
  }

  const saved = await chrome.storage.local.get(["code", "name"]);
  if (saved.code) return showDone(saved);

  const options = (text) => String(text || "").split("|").map((o) => o.trim()).filter(String);
  const signup = {
    submitLabel: copy.signup_button, sending: copy.form_sending, error: copy.form_error,
    questions: [
      { id: "name", question: copy.signup_name, type: "text" },
      { id: "year", question: copy.signup_year, type: "choice", options: options(copy.signup_year_options) },
      { id: "ai", question: copy.signup_ai, type: "choice", options: options(copy.signup_ai_options) },
      { id: "collab", question: copy.signup_collab, type: "long" },
    ],
  };
  $("signup").hidden = false;
  ProbeForm.render($("form"), signup, async (answers) => {
    const res = await chrome.runtime.sendMessage({ type: "signup", ...answers });
    if (!res || !res.ok) throw new Error("sign-up failed");
    showDone({ code: res.code, name: answers.name });
  });
  // The form stays locked until they agree to take part.
  const lock = () => { $("form").inert = !$("agree").checked; $("form").style.opacity = $("agree").checked ? 1 : 0.4; };
  $("agree").addEventListener("change", lock);
  lock();
})();
