// Runs on the chatbot sites. While the switch is on, it notes when the
// participant clicks or types in the prompt box (time and chatbot only) and,
// if a form is due, shows it at that moment. A form is due at the start of a
// new stretch of use; while they keep prompting they are left alone, until
// cap_minutes after the last form.
// It never reads what is in the prompt box or anywhere else on the page.
//
// It also runs on the website, where it does two other jobs:
//   the form tab   The app helper opens it when Claude, ChatGPT or VS Code is
//                  used as an app and a form is due: the same form, in a tab,
//                  because an app cannot be drawn over.
//   the home page  Sign-up and the instructions. A web page cannot see an
//                  extension, so this passes the little it needs back and forth.
(() => {
  const TOOLS = {
    "chatgpt.com": "ChatGPT", "chat.openai.com": "ChatGPT", "claude.ai": "Claude",
    "gemini.google.com": "Gemini", "copilot.microsoft.com": "Copilot", "copilot.com": "Copilot",
    "perplexity.ai": "Perplexity", "chat.deepseek.com": "DeepSeek",
  };
  const site = location.hostname.replace(/^www\./, "");
  const onSite = location.href.startsWith(self.PROBE_SITE + "/");
  // On the form tab, the helper names the app and itself in the address.
  const formTab = onSite && /\/form\.html$/.test(location.pathname);
  const asked = formTab && new URLSearchParams(location.search);
  const appTool = asked ? (asked.get("tool") || "").replace(/[^\w .-]/g, "").slice(0, 30) : "";
  const tool = appTool || TOOLS[site] || site;
  const source = appTool ? (/^app-[a-z]+$/.test(asked.get("source")) ? asked.get("source") : "app") : "browser";
  const PROMPT_BOX = 'textarea, [contenteditable]:not([contenteditable="false"]), [role="textbox"]';

  let state = {};   // copy of chrome.storage.local, kept current below
  let host = null;  // the overlay, while a form is open
  let box = null;   // the prompt box to hand focus back to
  let asking = false;
  let sent = false; // the form on this page has been sent
  let lastPing = 0; // the background worker decides what gets logged; this just spares it every keystroke

  const loaded = new Promise((done) => chrome.storage.local.get(null, (s) => { state = s || {}; done(); }));
  chrome.storage.onChanged.addListener((changes) => {
    for (const key in changes) state[key] = changes[key].newValue;
    if (host && !state.pending) closeForm(); // answered, here or in another tab
    if (changes.code || changes.name || changes.apps) tellHome();
  });

  function send(msg) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(msg, (res) => (res && !res.error ? resolve(res) : reject(res)));
      } catch (e) { reject(e); } // extension was reloaded or removed
    });
  }

  function onEvent(e) {
    if (host) {
      // Typing, pasting and shortcuts inside the form belong to the form. Hide
      // them from the site, which would otherwise pull them into its own prompt box.
      if (e.type !== "pointerdown" && e.composedPath().includes(host)) e.stopImmediatePropagation();
      return;
    }
    if (onSite) return; // the website has no prompt box
    const now = Date.now();
    if ((e.type !== "pointerdown" && e.type !== "keydown") || !state.code || now >= (state.onUntil || 0)) return; // off: do nothing
    const target = e.composedPath()[0];
    const found = target instanceof Element && target.closest(PROMPT_BOX);
    if (!found) return;
    // Have they left the chatbots alone for long enough (grace_minutes in the
    // sheet) that this counts as a new stretch of use? Worked out before the
    // ping below moves lastUse forward.
    const settings = (state.config && state.config.settings) || {};
    const quiet = (Number(settings.grace_minutes) || 5) * 60 * 1000;
    const fresh = now - (state.lastUse || 0) >= quiet;
    // Or have they kept going so long (cap_minutes) that it is time to ask again anyway?
    const capped = now - (state.lastForm || 0) >= (Number(settings.cap_minutes) || 15) * 60 * 1000;
    if (now - lastPing >= 10000) {
      lastPing = now;
      send({ type: "activity", tool }).catch(() => {});
    }
    if (asking || !(state.pending || ((fresh || capped) && now >= (state.nextAllowed || 0)))) return; // no form due
    asking = true;
    send({ type: "trigger" })
      .then((res) => { if (res.config) openForm(res, found); }, () => {})
      .then(() => { asking = false; });
  }
  // pointerdown and keydown are the triggers; the rest are only shielded while a form is open.
  for (const type of ["pointerdown", "keydown", "keyup", "keypress", "paste", "copy", "cut",
                      "compositionstart", "compositionupdate", "compositionend"]) {
    window.addEventListener(type, onEvent, true);
  }

  function openForm(res, promptBox) {
    box = promptBox;
    host = document.createElement("div");
    host.style.setProperty("position", "fixed");
    host.style.setProperty("inset", "0");
    host.style.setProperty("z-index", "2147483647");
    const root = host.attachShadow({ mode: "closed" });
    const sheet = new CSSStyleSheet();
    sheet.replaceSync(res.css);
    root.adoptedStyleSheets = [sheet];

    // A floating window: a title bar to drag it by, and the form underneath.
    // There is deliberately no close or minimise button.
    const who = { name: String(state.name || "").trim().split(/\s+/)[0] };
    const form = ProbeForm.fromSheet(res.config, who);
    // A form opened for an app is a best guess that they are prompting, so it
    // offers a way out. In Chrome the click in the prompt box is exact, so it does not.
    if (appTool) {
      form.out = {
        label: ProbeForm.copy(res.config).app_out,
        send: () => send({ type: "submit", tool, source, answers: { just_reading: "yes" }, next: "now" }),
      };
    }
    const div = (className) => Object.assign(document.createElement("div"), { className });
    const backdrop = div("probe-backdrop");
    const win = div("probe-window");
    const bar = div("probe-bar probe-greeting");
    const card = div("");
    ProbeForm.fillInto(bar, ProbeForm.copy(res.config).form_title, who);
    win.append(bar, card);
    backdrop.append(win);
    root.append(backdrop);

    ProbeForm.render(card, { ...form, title: "" }, (all) => {
      const { next, ...answers } = all;
      // The form closes as soon as the answer is saved, which is before this
      // reply comes back, so note the send first and take it back if it fails.
      sent = true;
      return send({ type: "submit", tool, source, answers, next }).catch((e) => { sent = false; throw e; });
    });
    document.documentElement.append(host);

    // Start centred. From here it can be dragged by the bar and resized from its corner.
    const size = win.getBoundingClientRect();
    win.style.setProperty("left", Math.max(0, (innerWidth - size.width) / 2) + "px");
    win.style.setProperty("top", Math.max(0, (innerHeight - size.height) / 2) + "px");
    makeMovable(win, bar);
    const first = card.querySelector("button, input, textarea");
    if (first) first.focus();
    send({ type: "shown" }).catch(() => {});
  }

  // Drag the window by its bar. It always stays fully on screen.
  function makeMovable(win, bar) {
    bar.addEventListener("pointerdown", (down) => {
      if (down.button !== 0) return;
      const start = win.getBoundingClientRect();
      const dx = down.clientX - start.left;
      const dy = down.clientY - start.top;
      const move = (e) => {
        const r = win.getBoundingClientRect();
        const x = Math.min(Math.max(e.clientX - dx, 0), Math.max(0, innerWidth - r.width));
        const y = Math.min(Math.max(e.clientY - dy, 0), Math.max(0, innerHeight - r.height));
        win.style.setProperty("left", x + "px");
        win.style.setProperty("top", y + "px");
      };
      const stop = () => {
        bar.removeEventListener("pointermove", move);
        bar.removeEventListener("pointerup", stop);
        bar.removeEventListener("pointercancel", stop);
      };
      bar.setPointerCapture(down.pointerId);
      bar.addEventListener("pointermove", move);
      bar.addEventListener("pointerup", stop);
      bar.addEventListener("pointercancel", stop);
      down.preventDefault();
    });
  }

  function closeForm() {
    host.remove();
    host = null;
    if (box && box.isConnected) box.focus();
    if (appTool) say(sent ? "app_done" : "app_idle");
  }

  // ---- The website's form tab -------------------------------------------

  // The tab's own two lines of text, from the sheet's Copy tab.
  function say(key) {
    const copy = ProbeForm.copy(state.config);
    document.getElementById("title").textContent = copy[key] || "";
    document.getElementById("note").textContent = copy.app_close || "";
    document.querySelector("main").hidden = false;
  }

  if (onSite) document.documentElement.dataset.pause = "here"; // tells the page the extension is installed
  if (formTab) {
    const parsed = new Promise((done) => document.addEventListener("DOMContentLoaded", done, { once: true }));
    Promise.all([loaded, parsed])
      .then(() => (appTool ? send({ type: "trigger" }) : {}))
      .then((res) => (res.config ? openForm(res, null) : say("app_idle")), () => say("app_idle"));
  }

  // ---- The website's home page ------------------------------------------

  // The page asks with { pause: "ask" } and is answered with { pause: "tell" }.
  // It can learn who is signed up in this Chrome, sign someone up, and note
  // that the apps step was done or skipped. Nothing else passes through here.
  const home = onSite && !formTab;
  function tellHome(msg) {
    if (!home) return;
    window.postMessage(Object.assign({ pause: "tell" }, msg || {
      type: "state", name: state.name || "", code: state.code || "", apps: state.apps || "",
    }), location.origin);
  }
  if (home) {
    window.addEventListener("message", (e) => {
      if (e.source !== window || e.origin !== location.origin || !e.data || e.data.pause !== "ask") return;
      const ask = e.data;
      if (ask.type === "state") loaded.then(() => tellHome());
      if (ask.type === "apps") chrome.storage.local.set({ apps: ask.value === "skipped" ? "skipped" : "done" });
      if (ask.type === "signup") {
        const a = ask.answers || {};
        send({ type: "signup", name: a.name, year: a.year, ai: a.ai, collab: a.collab }).then(
          () => tellHome({ type: "signup", ok: true }), () => tellHome({ type: "signup", ok: false }));
      }
    });
  }
})();
