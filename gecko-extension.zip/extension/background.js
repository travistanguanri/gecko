// Background worker: talks to the Google Sheet and keeps the participant's
// state in chrome.storage.local:
//   code, name   who this is (set once at sign-up)
//   apps         "done" or "skipped" once they have been through the website's
//                apps step (written by content.js)
//   onUntil      the switch: on while Date.now() < onUntil
//   room         code of the discussion they are in ("" when in none)
//   starter      who started that discussion ("" when they did)
//   lastRoom     the code they were in when the switch ran out by itself, offered
//                back in the popup until roomUntil, when it can no longer be joined
//   nextAllowed  no new form before this time
//   lastUse      when they last touched a chatbot's prompt box or sent a form:
//                a new form waits until they have left the chatbots alone a while
//   lastForm     when a form was last put up or sent: during non-stop use, the
//                next one comes cap_minutes after it
//   pending      a form has been shown and not answered yet
//   promptedAt   when that form first appeared, and promptRoom, the discussion it appeared in
//   lastActivity when each chatbot was last written to the Activity tab
//   fronts       the chatbot tabs in front right now: tab -> { tool, start, room }
//   queue        responses still waiting to reach the sheet
//   config       last copy of the sheet's settings and questions
if (typeof importScripts === "function") importScripts("config.js");

const ENDPOINT = self.PROBE_ENDPOINT;
const SITE = self.PROBE_SITE; // the website: sign-up and instructions, the form tab for apps, the report
const store = chrome.storage.local;
const CONFIG_MAX_AGE = 60 * 1000;

async function post(body) {
  const res = await fetch(ENDPOINT, { method: "POST", body: JSON.stringify(body) });
  return res.json();
}

// Use the saved copy straight away so the form opens instantly; refresh it
// from the sheet when it is over a minute old.
async function getConfig(fresh) {
  const { config, configAt = 0 } = await store.get(["config", "configAt"]);
  if (config && !fresh && Date.now() - configAt < CONFIG_MAX_AGE) return config;
  const refresh = fetch(ENDPOINT + "?action=config")
    .then((res) => res.json())
    .then(async (latest) => { await store.set({ config: latest, configAt: Date.now() }); return latest; });
  if (!config || fresh) return refresh.catch(() => config || null);
  refresh.catch(() => {});
  return config;
}

async function signUp(msg) {
  const res = await post({ action: "signup", name: msg.name, year: msg.year, ai: msg.ai, collab: msg.collab });
  if (!res.ok) throw new Error(res.error);
  await store.set({ code: res.code, name: msg.name });
  return { ok: true, code: res.code };
}

// Start a discussion (no code given) or join one by its code. Being in a
// discussion is what switches the probe on. msg.at is the moment they pressed
// the button: for whoever starts, that is the moment they say the sync word.
async function enterRoom(msg) {
  const { code } = await store.get("code");
  const at = Number(msg.at) || Date.now();
  const config = await getConfig();
  const hours = Number(config && config.settings.auto_off_hours) || 3;
  const onUntil = at + hours * 3600 * 1000;
  const res = await post({ action: "room", code, room: msg.room || "", at: new Date(at).toISOString(), onUntil });
  if (!res.ok) return { ok: false, error: res.error };
  // A new discussion asks at the first use of AI in it: a wait chosen on a form
  // in an earlier discussion is dropped. Coming back into the same one keeps it.
  await store.set(Object.assign({
    room: res.room, starter: msg.room ? res.starter : "", lastRoom: "", roomUntil: res.until,
    onUntil, switchSynced: true,
  }, res.rejoin ? {} : { nextAllowed: 0 }));
  showBadge();
  return { ok: true };
}

// Switch off, which also leaves the discussion. auto: the switch ran out by itself.
async function leaveRoom(auto) {
  const { code, room, onUntil = 0 } = await store.get(["code", "room", "onUntil"]);
  await endFronts(() => true, auto ? onUntil : Date.now()); // leaving ends any chatbot in front
  await store.set({ room: "", lastRoom: auto ? room : "", onUntil: 0, switchSynced: false });
  showBadge();
  if (room) {
    await changeQueue((queue) => queue.concat({
      action: "leave", id: crypto.randomUUID(), code, room, auto: Boolean(auto),
      at: new Date(auto ? onUntil : Date.now()).toISOString(),
    }));
  }
  await syncSwitch();
  await flushQueue();
  // They chose to switch off: show them what the discussion looked like. The
  // codes go after the #, which stays in the browser and is never sent anywhere.
  if (room && !auto) chrome.tabs.create({ url: SITE + "/report.html#room=" + room + "&me=" + code });
  return { ok: true };
}

// The switch has run out: note that they left. Checked before anything else
// happens, because the alarm for it can be late if the laptop was asleep.
async function expire() {
  const { room, onUntil = 0 } = await store.get(["room", "onUntil"]);
  if (room && Date.now() >= onUntil) await leaveRoom(true);
}

// The app helper reads the switch from the sheet, so keep the sheet's copy current.
async function syncSwitch() {
  const { code, onUntil = 0, switchSynced } = await store.get(["code", "onUntil", "switchSynced"]);
  if (!code || switchSynced) return;
  try {
    const res = await post({ action: "switch", code, onUntil });
    if (res.ok) await store.set({ switchSynced: true });
  } catch (e) {}
}

async function showBadge() {
  const { onUntil = 0 } = await store.get("onUntil");
  const on = Date.now() < onUntil;
  chrome.action.setBadgeText({ text: on ? "ON" : "" });
  chrome.action.setBadgeBackgroundColor({ color: "#1d1d1f" });
  // While on, re-read the sheet every minute so edits to the wording or the
  // questions are already here when the next form opens.
  if (on) {
    chrome.alarms.create("auto-off", { when: onUntil });
    chrome.alarms.create("refresh", { periodInMinutes: 1 });
  } else {
    chrome.alarms.clear("auto-off");
    chrome.alarms.clear("refresh");
  }
}

// The participant clicked or typed in a prompt box and the content script
// thinks a form is due. Hand over the form so it opens at once.
async function trigger() {
  const s = await store.get(["code", "onUntil", "nextAllowed", "pending", "promptedAt", "promptRoom", "room"]);
  const now = Date.now();
  if (!s.code || now >= (s.onUntil || 0) || (!s.pending && now < (s.nextAllowed || 0))) return {};
  const config = await getConfig();
  if (!config) return {};
  const css = await (await fetch(chrome.runtime.getURL("form.css"))).text();
  // A form that comes back unanswered keeps the time it first appeared, as long
  // as that was in this same discussion. One left over from an earlier
  // discussion is about this moment now, so it gets this time and this code.
  const room = s.room || "";
  await store.set(s.pending && s.promptedAt && (s.promptRoom || "") === room ? { pending: true, lastForm: now }
    : { pending: true, lastForm: now, promptedAt: now, promptRoom: room });
  return { config, css };
}

// The form is on screen. Now confirm with the sheet, which also hears from the
// app helper: if a form was answered there within the wait, take this one away.
async function shown() {
  const { code } = await store.get("code");
  await syncSwitch();
  try {
    const res = await post({ action: "check", code });
    if (res.prompt === false && res.reason === "cooldown") {
      await store.set({ pending: false, nextAllowed: res.nextAllowed });
    }
  } catch (e) {} // sheet unreachable: keep the form, the local timer still applies
  await flushQueue();
  return {};
}

async function submit(msg) {
  const { code, config, promptedAt, promptRoom } = await store.get(["code", "config", "promptedAt", "promptRoom"]);
  const s = (config && config.settings) || {};
  const minutes = Number({ now: s.grace_minutes, snooze: s.snooze_minutes }[msg.next] || s.cooldown_minutes) || 15;
  await changeQueue((queue) => queue.concat({
    action: "response", id: crypto.randomUUID(), code, room: promptRoom || "", tool: msg.tool,
    source: msg.source || "browser",
    answers: msg.answers, next: msg.next, at: new Date().toISOString(),
    promptedAt: new Date(promptedAt || Date.now()).toISOString(),
  }));
  // Saving this closes the form straight away; sending can take a moment longer.
  // Sending counts as a use, so the prompt they go on to type does not bring the form straight back.
  await store.set({
    pending: false, nextAllowed: Date.now() + minutes * 60 * 1000, lastUse: Date.now(), lastForm: Date.now(),
  });
  await flushQueue();
  return { ok: true };
}

// While the switch is on, note the time and the chatbot each time one is used,
// whether or not a form is due: at most one row per chatbot per minute.
// Every use, logged or not, also moves lastUse forward.
async function activity(msg) {
  const { code, onUntil = 0, room = "", config, lastActivity = {} } =
    await store.get(["code", "onUntil", "room", "config", "lastActivity"]);
  const now = Date.now();
  const every = (Number(config && config.settings.activity_seconds) || 60) * 1000;
  if (!code || now >= onUntil) return {};
  if (now - (lastActivity[msg.tool] || 0) < every) { await store.set({ lastUse: now }); return {}; }
  lastActivity[msg.tool] = now;
  await store.set({ lastActivity, lastUse: now });
  await changeQueue((queue) => queue.concat({
    action: "activity", id: crypto.randomUUID(), code, room, tool: msg.tool, source: "browser",
    at: new Date(now).toISOString(),
  }));
  await flushQueue();
  return {};
}

// A chatbot tab came to the front (msg.on) or stopped being there. Each stretch
// in front becomes one Opens row, sent when it ends: when they look away, close
// the tab, or leave the discussion. Kept in storage rather than in this
// worker, which Chrome stops when idle. One change at a time, like the queue.
let frontGate = Promise.resolve();
function front(msg, sender) {
  const tab = sender && sender.tab ? String(sender.tab.id) : "";
  if (!tab) return Promise.resolve({});
  frontGate = frontGate.catch(() => {}).then(async () => {
    if (!msg.on) return endFronts((t) => t === tab, Number(msg.at) || Date.now());
    const { code, onUntil = 0, room = "", fronts = {} } = await store.get(["code", "onUntil", "room", "fronts"]);
    const now = Date.now();
    if (!code || !room || now >= onUntil || fronts[tab]) return;
    fronts[tab] = { tool: msg.tool, start: now, room };
    await store.set({ fronts });
  });
  return frontGate.then(() => ({}));
}
async function endFronts(which, at) {
  const { code, fronts = {} } = await store.get(["code", "fronts"]);
  const ended = Object.keys(fronts).filter(which);
  if (!ended.length) return;
  await changeQueue((queue) => queue.concat(ended.map((t) => ({
    action: "open", id: crypto.randomUUID(), code, room: fronts[t].room, tool: fronts[t].tool,
    start: new Date(fronts[t].start).toISOString(), end: new Date(Math.max(fronts[t].start, at)).toISOString(),
  }))));
  ended.forEach((t) => delete fronts[t]);
  await store.set({ fronts });
  flushQueue();
}
if (chrome.tabs && chrome.tabs.onRemoved) {
  chrome.tabs.onRemoved.addListener((tabId) => {
    frontGate = frontGate.catch(() => {}).then(() => endFronts((t) => t === String(tabId), Date.now()));
  });
}

// Every change to the queue goes through here, one at a time, so an answer
// being added can never be overwritten by another change landing with it.
let queueGate = Promise.resolve();
function changeQueue(change) {
  queueGate = queueGate.catch(() => {}).then(async () => {
    const { queue = [] } = await store.get("queue");
    await store.set({ queue: change(queue) });
  });
  return queueGate;
}

// Send what is waiting (responses, activity, leaving a discussion), oldest
// first, one flush at a time. Anything that fails stays queued for next time;
// the sheet ignores a response id it already has.
let flushing = Promise.resolve();
function flushQueue() {
  flushing = flushing.then(sendQueue, sendQueue);
  return flushing;
}
async function sendQueue() {
  const { queue = [] } = await store.get("queue");
  for (const item of queue) {
    try {
      const res = await post(item);
      // Keep it for a retry, unless the sheet will never accept it; those
      // must not hold up everything behind them.
      if (!res.ok && res.error !== "unknown code" && res.error !== "unknown action") break;
    } catch (e) { break; }
    await changeQueue((latest) => latest.filter((q) => q.id !== item.id));
  }
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  const job = () => (msg.type === "signup" ? signUp(msg)
    : msg.type === "room" ? enterRoom(msg)
    : msg.type === "leave" ? leaveRoom()
    : msg.type === "config" ? getConfig(msg.fresh)
    : msg.type === "trigger" ? trigger()
    : msg.type === "shown" ? shown()
    : msg.type === "activity" ? activity(msg)
    : msg.type === "front" ? front(msg, sender)
    : msg.type === "submit" ? submit(msg)
    : Promise.resolve({}));
  expire().then(job).then(reply, (e) => reply({ error: String(e) }));
  return true;
});

// Sign-up is on the website's home page. Someone who has just added Gecko
// usually still has that page open from downloading it: go back to that tab,
// loaded again so it can see Gecko is here now. Otherwise open the page.
async function openSite() {
  try {
    const tabs = await chrome.tabs.query({});
    // A tab's address is only readable for the website, which is all that is needed.
    const home = tabs.find((t) => t.url && t.url.startsWith(SITE)
      && /^\/?(index\.html)?([?#]|$)/.test(t.url.slice(SITE.length)));
    if (home) {
      await chrome.tabs.reload(home.id);
      await chrome.tabs.update(home.id, { active: true });
      await chrome.windows.update(home.windowId, { focused: true });
      return;
    }
  } catch (e) {}
  chrome.tabs.create({ url: SITE + "/" });
}

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") openSite();
  showBadge();
});
chrome.runtime.onStartup.addListener(() => { expire().then(showBadge); flushQueue(); });
chrome.alarms.onAlarm.addListener((alarm) =>
  (alarm.name === "refresh" ? getConfig(true) : expire().then(showBadge)));
