// The popup behind the toolbar icon. Not in a discussion: start one, or join
// one with its code. In a discussion: its code, and the switch to leave.
// Its wording comes from the Copy tab of the sheet. Sign-up and the
// instructions are on the website's home page, which both links here open.
const HOME = self.PROBE_SITE + "/";
const $ = (id) => document.getElementById(id);
const firstName = (name) => String(name || "").trim().split(/\s+/)[0];
let s = {};            // saved state, see background.js
let copy = {};
let busy = false;      // waiting for the sheet
let justStarted = false; // this popup pressed Start: show what to say out loud
let problem = "";      // why Start or Join did not work
let offered = false;   // the last code has been put in the box once
const isOn = () => Date.now() < (s.onUntil || 0);

// Time left before the switch turns itself off, as h:mm:ss.
function countdown() {
  const left = Math.max(0, Math.ceil((s.onUntil - Date.now()) / 1000));
  const two = (n) => String(n).padStart(2, "0");
  return Math.floor(left / 3600) + ":" + two(Math.floor((left % 3600) / 60)) + ":" + two(left % 60);
}

function show() {
  if (!s.code) return;
  // Pressing Start shows the code screen at once, so the sync word is said at
  // the moment of the press; the code itself arrives a second or two later.
  const starting = busy && justStarted;
  const on = starting || isOn();
  $("off").hidden = on;
  $("on").hidden = !on;
  $("start").disabled = busy;
  $("join-button").disabled = busy || $("code").value.length !== 4;
  $("switch").disabled = busy;
  if (!on) {
    $("problem").textContent = busy ? copy.form_sending || "" : problem;
    return;
  }
  $("switch").setAttribute("aria-checked", "true");
  $("say").textContent = justStarted ? copy.popup_say || "" : "";
  $("say").hidden = !justStarted;
  $("room").textContent = starting ? "" : s.room || "";
  $("room").classList.toggle("probe-waiting", starting);
  $("room-note").textContent = s.starter
    ? ProbeForm.fill(copy.popup_joined, { starter: firstName(s.starter) })
    : copy.popup_room_label || "";
  $("room-note").hidden = justStarted;
  $("status").textContent = starting ? "" : ProbeForm.fill(copy.popup_on, { time: countdown() });
}

async function draw() {
  s = await chrome.storage.local.get(["code", "name", "onUntil", "room", "starter", "lastRoom", "roomUntil", "config"]);
  copy = ProbeForm.copy(s.config);
  $("link").textContent = copy.popup_link || "";
  $("signup").textContent = copy.popup_signup_button || "";
  $("signup").hidden = Boolean(s.code);
  if (!s.code) {
    $("hello").textContent = copy.popup_not_signed_up || "";
    return;
  }
  ProbeForm.fillInto($("hello"), copy.popup_hello, { name: firstName(s.name) });
  ProbeForm.rich($("start-label"), copy.popup_start_label); // **before** is shown bold
  $("start").textContent = copy.popup_start || "";
  $("join-label").textContent = copy.popup_join_label || "";
  $("join-button").textContent = copy.popup_join || "";
  $("code").placeholder = copy.popup_code_placeholder || "";
  $("code").setAttribute("aria-label", copy.popup_code_placeholder || "Code");
  // Switched off by the timer mid-discussion: their code is waiting in the box.
  if (!offered && s.lastRoom && Date.now() < (s.roomUntil || 0)) $("code").value = s.lastRoom;
  offered = true;
  show();
}

// room is "" to start a new discussion, or the code of one to join.
async function enter(room) {
  busy = true;
  problem = "";
  justStarted = !room;
  show();
  let res;
  try { res = await chrome.runtime.sendMessage({ type: "room", room, at: Date.now() }); } catch (e) {}
  busy = false;
  if (res && res.ok) {
    $("code").value = "";
  } else {
    justStarted = false;
    problem = (res && res.error === "no room" ? copy.popup_no_room : copy.form_error) || "";
  }
  await draw();
  if (problem && room) $("code").select(); // typing again replaces the code that did not work
}

$("signup").addEventListener("click", () => {
  chrome.tabs.create({ url: HOME });
});
$("start").addEventListener("click", () => enter(""));
$("join").addEventListener("submit", (e) => {
  e.preventDefault();
  if (!$("join-button").disabled) enter($("code").value);
});
$("code").addEventListener("focus", () => $("code").select()); // typing replaces a code already there
$("code").addEventListener("input", () => {
  $("code").value = $("code").value.toUpperCase().replace(/[^A-Z]/g, "");
  problem = "";
  show();
});

// Switching off leaves the discussion.
$("switch").addEventListener("click", async () => {
  // Flip straight away; telling the sheet takes a second or two.
  $("switch").setAttribute("aria-checked", "false");
  busy = true;
  $("switch").disabled = true;
  justStarted = false;
  try { await chrome.runtime.sendMessage({ type: "leave" }); } catch (e) {}
  busy = false;
  draw();
});

$("link").href = HOME;

// Show the saved wording at once, then pick up any edits made in the sheet.
draw();
chrome.storage.onChanged.addListener((changes) => {
  if (!busy && (changes.config || changes.room || changes.onUntil)) draw();
});
chrome.runtime.sendMessage({ type: "config", fresh: true });
setInterval(() => { if (!busy) show(); }, 1000);
